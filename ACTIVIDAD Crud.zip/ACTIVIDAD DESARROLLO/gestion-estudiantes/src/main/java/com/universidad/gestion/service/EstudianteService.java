package com.universidad.gestion.service;

import com.universidad.gestion.model.Estudiante;
import com.universidad.gestion.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService {
    
    @Autowired
    private EstudianteRepository estudianteRepository;
    
    public List<Estudiante> obtenerTodos() {
        return estudianteRepository.findAll();
    }
    
    public Optional<Estudiante> obtenerPorId(Long id) {
        return estudianteRepository.findById(id);
    }
    
    public Estudiante crearEstudiante(Estudiante estudiante) {
        return estudianteRepository.save(estudiante);
    }
    
    public Optional<Estudiante> actualizarEstudiante(Long id, Estudiante estudianteActualizado) {
        Optional<Estudiante> estudianteExistente = estudianteRepository.findById(id);
        if (estudianteExistente.isPresent()) {
            Estudiante estudiante = estudianteExistente.get();
            estudiante.setNombre(estudianteActualizado.getNombre());
            estudiante.setEdad(estudianteActualizado.getEdad());
            return Optional.of(estudianteRepository.save(estudiante));
        }
        return Optional.empty();
    }
    
    public boolean eliminarEstudiante(Long id) {
        if (estudianteRepository.existsById(id)) {
            estudianteRepository.deleteById(id);
            return true;
        }
        return false;
    }
}