const API_BASE_URL = '/api/estudiantes';

document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname === '/estudiantes') {
        cargarEstudiantes();
    }
    
    const formNuevo = document.getElementById('estudiante-form');
    if (formNuevo) {
        formNuevo.addEventListener('submit', guardarEstudiante);
    }
    
    const formEditar = document.getElementById('editar-form');
    if (formEditar) {
        formEditar.addEventListener('submit', actualizarEstudiante);
        
        const urlParams = new URLSearchParams(window.location.search);
        const id = urlParams.get('id');
        
        if (id) {
            cargarEstudianteParaEditar(id);
        } else {
            mostrarError('No se proporcionó ID de estudiante');
        }
    }
});

function filtrarEstudiantes() {
    const id = document.getElementById('search-id').value;
    
    if (id && id.trim() !== '') {
        buscarEstudiantePorId(id);
    } else {
        cargarEstudiantes();
    }
}

function limpiarBusqueda() {
    document.getElementById('search-id').value = '';
    cargarEstudiantes();
}

async function buscarEstudiantePorId(id) {
    const loading = document.getElementById('loading');
    const estudiantesList = document.getElementById('estudiantes-list');
    const singleStudent = document.getElementById('single-student');
    const errorMessage = document.getElementById('error-message');
    
    loading.style.display = 'block';
    estudiantesList.style.display = 'none';
    singleStudent.style.display = 'none';
    errorMessage.style.display = 'none';
    
    try {
        const response = await fetch(`${API_BASE_URL}/${id}`);
        
        if (response.ok) {
            const estudiante = await response.json();
            
            singleStudent.innerHTML = `
                <div class="estudiante-card">
                    <h3>${estudiante.nombre}</h3>
                    <p><strong>ID:</strong> ${estudiante.id}</p>
                    <p><strong>Edad:</strong> ${estudiante.edad} años</p>
                    <div class="estudiante-actions">
                        <button onclick="editarEstudiante(${estudiante.id})" class="btn btn-primary">Editar</button>
                        <button onclick="eliminarEstudiante(${estudiante.id})" class="btn btn-danger">Eliminar</button>
                    </div>
                </div>
            `;
            
            singleStudent.style.display = 'block';
            
        } else if (response.status === 404) {
            errorMessage.textContent = `No se encontró ningún estudiante con ID: ${id}`;
            errorMessage.style.display = 'block';
        } else {
            throw new Error('Error en la búsqueda');
        }
        
    } catch (error) {
        errorMessage.textContent = 'Error al buscar el estudiante. Verifique el ID e intente nuevamente.';
        errorMessage.style.display = 'block';
    } finally {
        loading.style.display = 'none';
    }
}

async function cargarEstudiantes() {
    const loading = document.getElementById('loading');
    const estudiantesList = document.getElementById('estudiantes-list');
    const singleStudent = document.getElementById('single-student');
    const errorMessage = document.getElementById('error-message');
    
    loading.style.display = 'block';
    estudiantesList.style.display = 'none';
    singleStudent.style.display = 'none';
    errorMessage.style.display = 'none';
    
    try {
        const response = await fetch(API_BASE_URL);
        if (!response.ok) {
            throw new Error('Error al cargar estudiantes');
        }
        
        const estudiantes = await response.json();
        
        loading.style.display = 'none';
        estudiantesList.style.display = 'grid';
        
        if (estudiantes.length === 0) {
            estudiantesList.innerHTML = '<p>No hay estudiantes registrados.</p>';
            return;
        }
        
        estudiantesList.innerHTML = estudiantes.map(estudiante => `
            <div class="estudiante-card">
                <h3>${estudiante.nombre}</h3>
                <p><strong>ID:</strong> ${estudiante.id}</p>
                <p><strong>Edad:</strong> ${estudiante.edad} años</p>
                <div class="estudiante-actions">
                    <button onclick="editarEstudiante(${estudiante.id})" class="btn btn-primary">Editar</button>
                    <button onclick="eliminarEstudiante(${estudiante.id})" class="btn btn-danger">Eliminar</button>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        loading.style.display = 'none';
        errorMessage.style.display = 'block';
    }
}

async function cargarEstudianteParaEditar(id) {
    const loading = document.getElementById('loading');
    const errorMessage = document.getElementById('error-message');
    
    if (loading) loading.style.display = 'block';
    if (errorMessage) errorMessage.style.display = 'none';
    
    try {
        const response = await fetch(`${API_BASE_URL}/${id}/editar`);
        
        if (response.ok) {
            const estudiante = await response.json();
            
            document.getElementById('id').value = estudiante.id;
            document.getElementById('nombre').value = estudiante.nombre;
            document.getElementById('edad').value = estudiante.edad;
            
        } else if (response.status === 404) {
            mostrarError('Estudiante no encontrado');
        } else {
            throw new Error('Error al cargar estudiante');
        }
        
    } catch (error) {
        mostrarError('Error al cargar la información del estudiante');
    } finally {
        if (loading) loading.style.display = 'none';
    }
}

async function guardarEstudiante(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const estudiante = {
        nombre: formData.get('nombre'),
        edad: parseInt(formData.get('edad'))
    };
    
    try {
        const response = await fetch(API_BASE_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(estudiante)
        });
        
        const messageDiv = document.getElementById('message');
        
        if (response.ok) {
            const nuevoEstudiante = await response.json();
            
            if (messageDiv) {
                messageDiv.textContent = `Estudiante "${nuevoEstudiante.nombre}" creado exitosamente!`;
                messageDiv.className = 'message success';
                messageDiv.style.display = 'block';
            }
            
            form.reset();
            
            setTimeout(() => {
                window.location.href = '/estudiantes';
            }, 1500);
        } else {
            throw new Error('Error al crear estudiante');
        }
    } catch (error) {
        const messageDiv = document.getElementById('message');
        if (messageDiv) {
            messageDiv.textContent = 'Error al crear el estudiante. Por favor, intente nuevamente.';
            messageDiv.className = 'message error';
            messageDiv.style.display = 'block';
        }
    }
}

async function actualizarEstudiante(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const estudiante = {
        nombre: formData.get('nombre'),
        edad: parseInt(formData.get('edad'))
    };
    
    const id = formData.get('id');
    
    try {
        const response = await fetch(`${API_BASE_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(estudiante)
        });
        
        const messageDiv = document.getElementById('message');
        
        if (response.ok) {
            const estudianteActualizado = await response.json();
            
            if (messageDiv) {
                messageDiv.textContent = `Estudiante "${estudianteActualizado.nombre}" actualizado exitosamente!`;
                messageDiv.className = 'message success';
                messageDiv.style.display = 'block';
            }
            
            setTimeout(() => {
                window.location.href = '/estudiantes';
            }, 1500);
            
        } else if (response.status === 404) {
            if (messageDiv) {
                messageDiv.textContent = 'Error: Estudiante no encontrado';
                messageDiv.className = 'message error';
                messageDiv.style.display = 'block';
            }
        } else {
            throw new Error('Error al actualizar estudiante');
        }
        
    } catch (error) {
        const messageDiv = document.getElementById('message');
        if (messageDiv) {
            messageDiv.textContent = 'Error al actualizar el estudiante. Por favor, intente nuevamente.';
            messageDiv.className = 'message error';
            messageDiv.style.display = 'block';
        }
    }
}

async function eliminarEstudiante(id) {
    if (!confirm('¿Está seguro de que desea eliminar este estudiante?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            alert('Estudiante eliminado exitosamente');
            cargarEstudiantes();
        } else {
            throw new Error('Error al eliminar estudiante');
        }
    } catch (error) {
        alert('Error al eliminar el estudiante');
    }
}

function editarEstudiante(id) {
    window.location.href = `/editar-estudiante?id=${id}`;
}

function mostrarError(mensaje) {
    const errorMessage = document.getElementById('error-message');
    if (errorMessage) {
        errorMessage.innerHTML = `${mensaje}. <a href="/estudiantes" style="color: #3498db; text-decoration: underline;">Volver a la lista</a>`;
        errorMessage.style.display = 'block';
    }
}

function cancelarEdicion() {
    if (confirm('¿Está seguro de que desea cancelar la edición? Los cambios no guardados se perderán.')) {
        window.location.href = '/estudiantes';
    }
}