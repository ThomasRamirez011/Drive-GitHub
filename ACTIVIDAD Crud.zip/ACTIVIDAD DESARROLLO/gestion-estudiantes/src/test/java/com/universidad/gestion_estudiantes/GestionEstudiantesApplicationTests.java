package com.universidad.gestion_estudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionEstudiantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
