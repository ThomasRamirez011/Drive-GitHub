package com.gesgan.aplicacion_web_gesgan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemasDeGestionGanaderaApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(SistemasDeGestionGanaderaApplication.class, args);
    }
}
