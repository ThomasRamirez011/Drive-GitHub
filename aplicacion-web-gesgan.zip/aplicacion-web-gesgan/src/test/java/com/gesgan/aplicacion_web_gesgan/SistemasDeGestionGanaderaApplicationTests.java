package com.gesgan.aplicacion_web_gesgan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemasDeGestionGanaderaApplicationTests {

	@Test
	void contextLoads() {
	}

}
